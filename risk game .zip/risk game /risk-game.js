// Game state management
export function initializeGame(projectName, budget, duration, riskContingency) {
    window.gameState = {
        project: {
            name: projectName,
            budget: budget,
            duration: duration,
            riskContingency: (budget * riskContingency) / 100,
            remainingBudget: budget,
            quality: 100,
            currentTurn: 0
        },
        risks: []
    };
}

// Risk management functions
export function addRisk(risk) {
    if (!window.gameState) {
        return { success: false, message: 'Game not initialized' };
    }
    risk.id = Date.now();
    window.gameState.risks.push(risk);
    return { success: true };
}

export function calculateRiskScore(risk) {
    return (risk.likelihood * risk.impact);
}

export function getRiskLevel(score) {
    if (score <= 6) return 'Low';
    if (score <= 12) return 'Medium';
    if (score <= 20) return 'High';
    return 'Critical';
}

// Game progression
export function processTurn() {
    const state = window.gameState;
    if (!state) {
        return { success: false, message: 'Game not initialized' };
    }

    state.project.currentTurn++;
    const occurredRisks = [];

    // Process each risk
    state.risks.forEach(risk => {
        // Calculate if risk occurs based on likelihood
        const riskOccurs = Math.random() < (risk.likelihood / 5);
        if (riskOccurs) {
            // Apply risk impact
            const costImpact = (risk.minCost + (state.project.budget * risk.costPercentage / 100));
            state.project.remainingBudget -= costImpact;
            state.project.quality -= (risk.impact * 2);
            occurredRisks.push(risk);
        }
    });

    // Ensure quality doesn't go below 0
    state.project.quality = Math.max(0, state.project.quality);

    // Check if game is over
    const isGameOver = state.project.currentTurn >= state.project.duration || 
                      state.project.remainingBudget <= 0 ||
                      state.project.quality <= 0;

    return {
        success: true,
        turn: state.project.currentTurn,
        remainingBudget: state.project.remainingBudget,
        quality: state.project.quality,
        occurredRisks: occurredRisks,
        isGameOver: isGameOver
    };
}

// Scoring and game completion
export function calculateFinalScore() {
    const state = window.gameState;
    if (!state) return 0;

    const budgetScore = Math.max(0, (state.project.remainingBudget / state.project.budget) * 40);
    const qualityScore = (state.project.quality / 100) * 40;
    const completionScore = (state.project.currentTurn / state.project.duration) * 20;

    return Math.round(budgetScore + qualityScore + completionScore);
}

// Utility functions
export function exportGameState() {
    return window.gameState || {
        project: {
            name: '',
            budget: 0,
            duration: 0,
            riskContingency: 0,
            remainingBudget: 0,
            quality: 100,
            currentTurn: 0
        },
        risks: []
    };
} 